
DER TOUR Motion klub – low‑fi prototyp & mock API
=================================================

Obsah složky:
- index.html – výchozí stránka (volba role)
- guest-login.html → program.html → basket.html → program-booked.html → my-activities.html
- animator-login.html → animator-registrations.html / animator-add.html / animator-cancel.html
- styles.css – low‑fi vzhled
- mock-api/*.json – mock datové payloady podle navržených endpointů

Doporučení pro Lovable:
- Každý endpoint nadefinujte jako REST mock a nahrajte obsah odpovědí z JSON souborů.
- Akce tlačítek mohou volat "fake" fetch na daný mock a zobrazit toast (viz připravené obrazovky).
- Paleta a typografie v produkci vycházejí z DERTOUR styleguide (zde low‑fi).

Autor: ChatGPT
